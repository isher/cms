<?php
return array(
	'webconsole.meta.name'			    => 'webconsole',
	'webconsole.meta.title'			=> 'webconsole',
	'webconsole.meta.desc' 			=> 'webconsole.'
);