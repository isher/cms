<?php
class webconsolePlugin extends PluginBase {
    function __construct() {
        parent::__construct();
    }
    
    public function regiest() {
        $this->hookRegiest(array(
            'templateCommonHeader' => 'webconsolePlugin.addMenu'
        ));
    }
    
    public function addMenu() {
        $config = $this->getConfig();
        $subMenu = $config['menuSubMenu'];
        
        navbar_menu_add(array(
            'name'      => LNG('webconsole.meta.name'),
            'icon'      => $this->appIcon(),
            'url'       => 'javascript:(core.openWindow("' . $this->pluginApi . '", "' . LNG('webconsole.meta.name') . '"))',
            'target'    => '',
            'subMenu'   => $subMenu,
            'use'       => '1'
        ));
    }
    
    public function index() {
        header('Location: ' . $this->pluginHost . 'webconsole/');
    }
}