<?php
return array(
	'webconsole.meta.name'			    => 'Web控制台',
	'webconsole.meta.title'			=> 'Web控制台',
	'webconsole.meta.desc' 			=> 'Web控制台'
);