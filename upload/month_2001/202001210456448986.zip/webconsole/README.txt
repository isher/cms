# About

使用前必须先配置Web控制台：

在您喜爱的文本编辑器中打开Web控制台的php文件，位置在/plugins/webconsole/webconsole//index.php
在文件的开头，输入$USER和$PASSWORD凭据，编辑您喜欢的任何其他设置（请参见注释中的说明）
将更改的文件上载到web服务器并在浏览器中打开
有关更多信息，请访问Web控制台网站：http://Web-Console.org 或 http://isher.qed.cn


Web Console is a web-based application that allows to execute shell commands on a server directly from a browser (web-based SSH).
The application is very light, does not require any database and can be installed and configured in about 3 minutes.

If you like Web Console, please consider an opportunity to support it on Patreon (https://www.patreon.com/nickola).

# Installation

Installation process is really simple:

  - Download latest version of the Web Console.
  - Unpack archive and open file "webconsole.php" in your favorite text editor.
  - At the beginning of the file enter your $USER and $PASSWORD credentials, edit any other settings that you like (see description in the comments).
  - Upload changed "webconsole.php" file to the web server and open it in the browser.

# About author

Web Console has been developed by Nickolay Kovalev (http://nickola.ru).
If you have interest job offers, you can see him contacts at his CV (http://cv.nickola.ru).
for kod by isher (http://isher.qed.cn).
Also, various third-party components are used.

# Used components

  - jQuery JavaScript Library: https://github.com/jquery/jquery
  - jQuery Terminal Emulator: https://github.com/jcubic/jquery.terminal
  - jQuery Mouse Wheel Plugin: https://github.com/brandonaaron/jquery-mousewheel
  - PHP JSON-RPC 2.0 Server/Client Implementation: https://github.com/sergeyfast/eazy-jsonrpc
  - Normalize.css: https://github.com/necolas/normalize.css

# URLs

 - GitHub: https://github.com/nickola/web-console
 - Patreon: https://www.patreon.com/nickola
 - Author: http://nickola.ru

# License

Web Console is licensed under GNU LGPL Version 3 (http://www.gnu.org/licenses/lgpl.html) license.